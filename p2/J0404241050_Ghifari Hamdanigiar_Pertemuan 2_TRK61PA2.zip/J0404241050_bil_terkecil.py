a = int(input("Masukkan bilangan a: "))
b = int(input("Masukkan bilangan b: "))
c = int(input("Masukkan bilangan c: "))

print("===========================================================")
print(f"bilangan a: {a}; bilangan b: {b}; bilangan c: {c}")
print(f"bilangan terkecil adalah: {min(a, b, c)}")